import React from "react";
import "./not_found_styles.css"

const Not_Found = (props) => {
    return(
        <div>
            <img src={"images/not_found.png"} alt={"not found"} className={"not_found_img"}/>
        </div>
    )
}

export default Not_Found